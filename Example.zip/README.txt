In this zip are all the files needed for a quick-and-dirty example I put together. 
Some basic Javascript and HTML skills are required, but I hope the comments in all three scripts are pretty self-explanatory. 
Tip: use Notepad++ and set the correct language when browsing through each file (the color-coding will help enormously). 

Let me know if this helped, and/or if any of the comments are hard to understand.
Cheers Achiel

HOW TO INTEGRATE EXPERIMENT TO MTURK
	1) Make a copy of the empty Mturk Template script included.
	2) Paste all HTML / CSS / JS to the proper locations. I've already done this in the file "Example Experiment.htm". 
	3) Go to the requester page of Mturk
	4) Create a new project (the type doesn't matter).
	5) In the "Design Layout" section, open the HTML editor of the code.
	6) Delete all Mturk-generated code. Instead, copy and paste all code from the file created in step 2. 
	7) Test the results ;). 